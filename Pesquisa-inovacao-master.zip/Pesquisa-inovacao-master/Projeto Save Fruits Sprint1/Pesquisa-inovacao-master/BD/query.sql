
create table Frutas1(
id int primary key identity(1,1),
Frutas varchar(20),
Temperatura_C int,
Umidade_Em_Porcentagem int
);


insert into Frutas1 (Frutas,Temperatura_C,Umidade_Em_Porcentagem) values 
('Pera',0,90),
('Kiwi',1,90),
('Cereja',0,90);
